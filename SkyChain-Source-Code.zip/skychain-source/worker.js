export default {async fetch(request,env){
 const url=new URL(request.url);
 if(!['GET','HEAD'].includes(request.method))return new Response('Method not allowed',{status:405});
 if(url.pathname==='/api/maps-config')return Response.json({key:env.GOOGLE_MAPS_BROWSER_KEY||''},{headers:{'Cache-Control':'no-store','X-Content-Type-Options':'nosniff'}});
 const asset=assets[url.pathname==='/'?'/index.html':url.pathname];
 if(!asset)return new Response('Not found',{status:404});
 const data=Uint8Array.from(atob(asset.body),c=>c.charCodeAt(0));
 return new Response(request.method==='HEAD'?null:data,{headers:{'Content-Type':asset.type,'Cache-Control':'no-cache','X-Content-Type-Options':'nosniff','Referrer-Policy':'strict-origin-when-cross-origin',...(url.pathname==='/sw.js'?{'Service-Worker-Allowed':'/'}:{})}});
}};
