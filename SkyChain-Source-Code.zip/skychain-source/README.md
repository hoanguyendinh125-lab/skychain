# SkyChain mobile pilot experience

Mobile PWA with a Cloudflare-compatible Worker. Source assets live in public/. Run npm run build then npm test. dist/ is generated output. No local development browser is configured.

Google Maps reads GOOGLE_MAPS_BROWSER_KEY from the Sites production environment through a no-store endpoint. No credential belongs in source or the service-worker cache. Browser Maps keys necessarily reach the browser; restrict this key in Google Cloud to https://skychain-mobile.hoanguyendinh125.chatgpt.site/* and Maps JavaScript API. Enable Geocoding API only if address search beyond the local demo list is wanted. A Maps key alone does not prove enabled billing/API/referrer settings.

All orders, medical-unit identity, UAV telemetry, cold-chain data, dispatch and OTP/POD are device-local simulations. Data from the previous v4 demo migrates on first visit. GPS is requested on tap. Selecting GPS as a destination persists those coordinates with the local order. Demo station coordinates are illustrative and not verified medical facility locations. Aerial polylines are not approved flight routes; road navigation uses an external Google Maps directions link.

PWA caches only the app shell on the same origin, never Google tiles or /api/ responses. Offline mode shows locally stored data and pauses simulation; a successful initial online load is required. Splash/login/role selection remain mandatory at every launch. Remember account stores an identifier only, not a password or authenticated session.

Validation: core state and Worker tests cover completion, cancellation, alert pause, expired/invalid OTP, POD, route mode, environment configuration and assets. No actual browser/GPS/API authorization verification is implied by these tests.
