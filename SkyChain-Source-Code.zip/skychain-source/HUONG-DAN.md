# Mã nguồn SkyChain Logistics

Bản xuất từ phiên bản đã xuất bản của SkyChain. Toàn bộ giao diện, mô phỏng, PWA và Worker được giữ nguyên. Bổ sung run-local.mjs để chạy trên máy cá nhân. Không chứa API key, lịch sử Git hay dữ liệu đơn trên thiết bị của người dùng.

## Chạy bằng VS Code

1. Cài Node.js 22 trở lên. Giải nén ZIP và mở thư mục skychain-source bằng VS Code.
2. Mở Terminal trong thư mục đó.
3. Sao chép .env.example thành .env. Nếu dùng Maps, điền key riêng sau GOOGLE_MAPS_BROWSER_KEY=. Có thể để trống để xem các luồng demo không có bản đồ.
4. Chạy:

```sh
npm run build
node --env-file=.env run-local.mjs
```

5. Mở http://localhost:3000. Nhấn Ctrl+C trong Terminal để dừng.

Dự án không có thư viện npm phụ thuộc nên không cần npm install. Mỗi lần sửa mã, chạy lại build và khởi động lại server. Không mở index.html bằng cách nhấp đúp vì bản đồ cần endpoint cấu hình từ server.

Đăng nhập demo: tài khoản có sẵn, mật khẩu skychain2026. OTP hiển thị trong màn hình nhận hàng khi chuyến đã đến nơi.

## Các file chính

- public/app.js: giao diện, điều hướng, các màn hình và thao tác.
- public/app.css, public/readability.css: thiết kế và chữ.
- public/core.js: đơn hàng, tính phương án và trạng thái mô phỏng.
- public/maps.js: Google Maps và GPS.
- public/sw.js, public/manifest.webmanifest: PWA và bộ nhớ đệm offline.
- worker.js: phục vụ ứng dụng và cấu hình bản đồ.
- build.mjs: đóng gói ứng dụng vào dist/server/index.js.
- test-core.mjs, test-ui.mjs: kiểm tra logic và dựng giao diện bằng mô phỏng DOM.

## Google Maps

Key không có trong ZIP. Cấu hình key của bạn qua .env trên máy, hoặc biến môi trường GOOGLE_MAPS_BROWSER_KEY khi hosting. Không đưa .env lên GitHub.

Maps JavaScript API phải được cho phép trong dự án Google Cloud và key cần chấp nhận website đang chạy. Khi thử local, cấu hình website restriction phù hợp với http://localhost:3000/*. Tìm địa chỉ ngoài danh sách demo cần Geocoding API. Các điều kiện thanh toán/quyền demo phụ thuộc tài khoản Google của bạn.

Key Maps dùng trên trình duyệt vẫn được gửi tới Google và có thể nhìn thấy qua yêu cầu mạng; biến môi trường không biến nó thành bí mật hoàn toàn. Giới hạn key theo website và API cần dùng.

## Kiểm tra và đưa lên hosting khác

```sh
npm run build
npm test
```

Worker đầu ra tương thích giao diện Cloudflare Workers fetch(request, env). Cần cấu hình biến môi trường khi triển khai. File .openai/hosting.json giữ mã Site gốc để tái tạo bản build; không dùng mã này để đăng ký một Site mới. ZIP không tự cấp quyền truy cập hay xuất bản vào tài khoản hosting.

Nếu bản cũ còn lưu trong trình duyệt, tải lại trang; khi phát triển có thể xóa service worker/cache của localhost qua Developer Tools. PWA/GPS trên điện thoại thường cần HTTPS; server local trong bản xuất chỉ mở trên chính máy tính của bạn.

Đơn, UAV, điều phối AI, chuỗi lạnh và OTP/POD là mô phỏng lưu cục bộ. Nền bản đồ và GPS dùng dịch vụ/thiết bị thật khi khả dụng. Chưa có backend xác thực, kết nối UAV, SMS hoặc điều phối y tế thật.
